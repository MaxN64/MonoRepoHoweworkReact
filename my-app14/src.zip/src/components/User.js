// src/components/User.js
import React from 'react';
import { connect } from 'react-redux';

/**
 * Дочерний (presentation) компонент, получает props user из Redux.
 */
function User(props) {
  const { name, status } = props.user;

  return (
    <div className="user-profile">
      <h2>User Profile</h2>
      <div className="user-info">
        <p><strong>Name:</strong> {name}</p>
        <p><strong>Status:</strong> {status}</p>
      </div>
    </div>
  );
}

/**
 * mapStateToProps: какие части state мы хотим передать в props.
 * Здесь мы передаём только `state.user`.
 */
const mapStateToProps = (state) => {
  return {
    user: state.user,
  };
};

// Подключаем компонент к Redux store
export default connect(mapStateToProps)(User);

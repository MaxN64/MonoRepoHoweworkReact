// src/components/UserForm.js
import React, { useState, useEffect } from 'react';
import { connect } from 'react-redux';
import { setUserInfo } from '../redux/actions';

/**
 * Компонент формы для редактирования имени и статуса.
 * Через connect получает текущие значения name/status и функцию setUserInfo.
 */
function UserForm(props) {
  // Локальные состояния для полей формы
  const [name, setName] = useState('');
  const [status, setStatus] = useState('');

  // При загрузке компонента заполняем локальные состояния значениями из Redux (чтобы форма показывала текущие)
  useEffect(() => {
    if (props.user) {
      setName(props.user.name);
      setStatus(props.user.status);
    }
  }, [props.user]);

  // Обработчик сабмита формы
  const handleSubmit = (e) => {
    e.preventDefault();
    // Простая валидация: оба поля должны быть непустыми
    if (name.trim() === '' || status.trim() === '') {
      alert('Пожалуйста, заполните оба поля.');
      return;
    }
    // Диспатчим экшен для обновления в Redux
    props.setUserInfo({ name: name.trim(), status: status.trim() });
    // Можно, например, показать сообщение или очистить форму.
    // Но оставим поля заполненными, так удобнее видеть текущее значение.
  };

  return (
    <div className="user-form">
      <h2>Edit User Information</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="nameInput"><strong>Name:</strong></label>
          <input
            id="nameInput"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Введите имя"
          />
        </div>
        <div className="form-group">
          <label htmlFor="statusInput"><strong>Status:</strong></label>
          <input
            id="statusInput"
            type="text"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            placeholder="Введите статус"
          />
        </div>
        <button type="submit">Save</button>
      </form>
    </div>
  );
}

/**
 * mapStateToProps: берём текущий user из Redux store
 */
const mapStateToProps = (state) => {
  return {
    user: state.user,
  };
};

/**
 * mapDispatchToProps: передаём action creator в props
 */
const mapDispatchToProps = {
  setUserInfo,
};

// Подключаем форму к Redux
export default connect(mapStateToProps, mapDispatchToProps)(UserForm);

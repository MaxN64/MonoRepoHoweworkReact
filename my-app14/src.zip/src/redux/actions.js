// src/redux/actions.js

// Тип действия для установки/обновления информации о пользователе
export const SET_USER_INFO = 'SET_USER_INFO';

/**
 * Action Creator для обновления информации о пользователе.
 * @param {{ name: string, status: string }} payload — объект с новой информацией
 * @returns {{ type: string, payload: { name: string, status: string } }}
 */
export function setUserInfo(payload) {
  return {
    type: SET_USER_INFO,
    payload, // ожидание: { name: 'Новое имя', status: 'Новый статус' }
  };
}

// src/redux/store.js
import { createStore } from 'redux';
import { rootReducer } from './reducers';

// Создаём Redux store
const store = createStore(
  rootReducer,
  // Добавим поддержку Redux DevTools (необязательно, но удобно в разработке):
  window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
);

export default store;


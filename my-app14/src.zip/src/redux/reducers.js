// src/redux/reducers.js
import { SET_USER_INFO } from './actions';

// Начальное состояние Redux store
const initialState = {
  user: {
    name: 'John Doe',
    status: 'online',
  },
};

/**
 * Root-редьюсер (простой вариант, так как у нас одна точка хранилища).
 * @param {{ user: { name: string, status: string } }} state
 * @param {{ type: string, payload: { name: string, status: string } }} action
 * @returns {{ user: { name: string, status: string } }}
 */
export function rootReducer(state = initialState, action) {
  switch (action.type) {
    case SET_USER_INFO:
      return {
        ...state,
        user: {
          name: action.payload.name,
          status: action.payload.status,
        },
      };
    default:
      return state;
  }
}

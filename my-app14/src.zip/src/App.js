// src/App.js
import React from 'react';
import { Provider } from 'react-redux';
import store from './redux/store';
import User from './components/User';
import UserForm from './components/UserForm';

import './App.css'; // наш файл стилей

function App() {
  return (
    <Provider store={store}>
      <div className="app-container">
        {/* Отображение профиля пользователя */}
        <User />

        {/* Форма для редактирования пользователя */}
        <UserForm />
      </div>
    </Provider>
  );
}

export default App;

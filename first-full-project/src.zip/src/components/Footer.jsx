// src/components/Footer.jsx
import React from 'react';
import styles from '../styles/Footer.module.css';

const Footer = () => {
  return (
    <footer>
      <small>Footer</small>
    </footer>
  );
};

export default Footer;

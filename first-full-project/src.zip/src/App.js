import "./App.css";
import MainPage from "./pages/Home";

function App() {
  return (
    <div className="App">
      <MainPage />
    </div>
  );
}

export default App;

// src/index.js
import React from 'react';
import ReactDOM from 'react-dom/client';        // <-- именно "react-dom/client"
import { Provider } from 'react-redux';
import store from './redux/store';
import App from './App';

// Находим в DOM наш корневой <div id="root"></div>
const container = document.getElementById('root');

// Теперь создаём root через новый createRoot API
const root = ReactDOM.createRoot(container);

root.render(
  <React.StrictMode>
    <Provider store={store}>
      <App />
    </Provider>
  </React.StrictMode>
);

// src/redux/store.js
import { createStore } from 'redux';
import { usersReducer } from './reducer';

// Создаём Redux-store
const store = createStore(
  usersReducer,
  // Подключаем Redux DevTools, если оно доступно в браузере
  window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
);

export default store;

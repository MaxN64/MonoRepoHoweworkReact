// src/redux/reducer.js
import { SET_FILTER } from './actions';

// Начальное состояние: список пользователей + текущая строка фильтра
const initialState = {
  users: [
    { id: 1, name: 'Alice' },
    { id: 2, name: 'Bob' },
    { id: 3, name: 'Charlie' },
    { id: 4, name: 'David' },
    { id: 5, name: 'Eve' },
    { id: 6, name: 'Frank' },
  ],
  filter: '',
};

// Редьюсер: обрабатывает только SET_FILTER
export const usersReducer = (state = initialState, action) => {
  switch (action.type) {
    case SET_FILTER:
      return {
        ...state,
        filter: action.payload,
      };
    default:
      return state;
  }
};

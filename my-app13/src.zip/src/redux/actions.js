// src/redux/actions.js

// Тип действия для установки фильтра
export const SET_FILTER = 'SET_FILTER';

// action creator для установки фильтра
export const setFilter = (filter) => ({
  type: SET_FILTER,
  payload: filter,
});

// src/App.js
import React from 'react';
import Filter from './components/Filter';
import UserList from './components/UserList';
import styles from './App.module.css'; // создадим лёгкий стиль для контейнера

const App = () => {
  return (
    <div className={styles.appContainer}>
      <h1 className={styles.title}>User List</h1>
      <Filter />
      <UserList />
    </div>
  );
};

export default App;

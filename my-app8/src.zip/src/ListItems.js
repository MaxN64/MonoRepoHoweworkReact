import React, { useState, useEffect } from 'react';


export default function ListItems() {
  const [items, setItems] = useState([]);
  const [inputValue, setInputValue] = useState('');

  const addItem = () => {
    if (inputValue.trim() === '') return;
    setItems(prev => [...prev, inputValue]);
    setInputValue('');
  };

  useEffect(() => {
    console.log('Компонент ListItems обновлен');
  }, [items]); // ← зависимость items вызывает лог при каждом изменении

  return (
    <div>
      <input
        type="text"
        value={inputValue}
        onChange={e => setInputValue(e.target.value)}
        placeholder="Введите элемент"
      />
      <button onClick={addItem}>Добавить</button>
      <ul>
        {items.map((item, idx) => (
          <li key={idx}>{item}</li>
        ))}
      </ul>
    </div>
  );
}

import UserProfile from './components/UserProfile';
 



function App() {
  return (
    <div>
     <UserProfile />
    </div>
  );
}

export default App;

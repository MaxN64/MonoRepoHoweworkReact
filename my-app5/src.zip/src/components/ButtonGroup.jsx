// src/components/ButtonGroup.jsx
import React from 'react';
import IconButton from './IconButton';

import apple      from '../assets/apple.svg';
import appleHover from '../assets/Apple1.svg';

import google      from '../assets/google.svg';
import googleHover from '../assets/Google1.svg';

import x      from '../assets/x.svg';
import xHover from '../assets/X1.svg';

import styles from '../styles/ButtonGroup.module.css';

const ButtonGroup = () => (
  <div className={styles.group}>
    <IconButton
      normalIcon={apple}
      hoverIcon={appleHover}
      alt="Sign in with Apple"
      onClick={() => {/* логика */}}
    />
    <IconButton
      normalIcon={google}
      hoverIcon={googleHover}
      alt="Sign in with Google"
      onClick={() => {/* логика */}}
    />
    <IconButton
      normalIcon={x}
      hoverIcon={xHover}
      alt="Sign in with X"
      onClick={() => {/* логика */}}
    />
  </div>
);

export default ButtonGroup;

import React from 'react';
import styles from '../styles/IconButton.module.css';

export default function IconButton({ normalIcon, hoverIcon, alt, onClick }) {
  return (
    <button
      className={styles.button}
      onClick={onClick}
      aria-label={alt}
    >
      <img src={normalIcon} className={`${styles.icon} ${styles.default}`} alt="" />
      <img src={hoverIcon}   className={`${styles.icon} ${styles.hover}`}   alt="" />
    </button>
  );
}
